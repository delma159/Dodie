# ProjetFinAnnée2020 - Config'o'Matic
Notre groupe : Chabeau Calvin, Basnet Devashish, Borca Mark, Salhi Adel

Notre projet est de réaliser un site répertoriant une série de composants afin de réaliser des
configurations personnalisées. Les prix des différents composants seront également ajouté afin de 
pouvoir visualiser le prix total d'une configuration.

Nous avons donc besoin d'une base de données composé de plusieurs tables, celles-ci serviront
à répertorier les informations des users, ainsi que les différents composants, leurs détails 
et leurs prix. Le site est donc une version personnalisé et simplifié de ce que propose le 
Configomatic de TopAchat. Pour cele nous avons donc choisis de proposer 7 types de composant
pour la réalisation des configs. Chaque type de composant proposera jusqu'a 8 choix différents (différentes marques/prix).

# TooDooList

-Base de composants
-Système d'enregistrement des configuration crées
-Site


